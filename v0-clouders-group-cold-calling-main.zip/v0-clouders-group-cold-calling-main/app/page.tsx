import { Header } from "@/components/header"
import { HeroSection } from "@/components/hero-section"
import { VideoSection } from "@/components/video-section"
import { FeaturesSection } from "@/components/features-section"
import { FAQSection } from "@/components/faq-section"
import { FinalCTASection } from "@/components/final-cta-section"
import { Footer } from "@/components/footer"

export default function Page() {
  return (
    <main className="min-h-screen bg-white">
      <Header />
      <HeroSection />
      <VideoSection />
      <FeaturesSection />
      <FAQSection />
      <FinalCTASection />
      <Footer />
    </main>
  )
}
