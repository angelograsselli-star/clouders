"use client"

export function VideoSection() {
  return (
    <section id="contenido" className="py-8 md:py-12 bg-secondary/30">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-5xl mx-auto space-y-8">
          {/* Video Container */}
          <div className="relative overflow-hidden rounded-2xl shadow-2xl" style={{ paddingTop: "56.25%" }}>
            <iframe
              className="absolute top-0 left-0 w-full h-full"
              src="https://www.youtube.com/embed/Iq4qASI1Fok"
              title="Video de Clouders Group"
              allow="accelerometer; autoplay; clipboard-write; encrypted-media; gyroscope; picture-in-picture"
              allowFullScreen
            />
          </div>
        </div>
      </div>
    </section>
  )
}
