"use client"

export function HeroSection() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <section className="py-4 md:py-6">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid gap-8 lg:grid-cols-2 lg:gap-12 items-center max-w-7xl mx-auto">
          {/* Left Column - Headline */}
          <div className="flex flex-col justify-center items-center text-center space-y-6 lg:min-h-[600px]">
            <h1 className="text-3xl font-bold tracking-tight text-foreground sm:text-4xl md:text-5xl lg:text-6xl xl:text-7xl text-balance">
              Escalá la adquisición de tu empresa de{" "}
              <span className="text-[#0c6ac3]">software o servicios B2B</span>
            </h1>
            <p className="text-base text-muted-foreground sm:text-lg md:text-xl text-pretty max-w-2xl">
              Con un sistema simple, probado y sin humo que combina marketing, proceso comercial y estrategia — para que
              más y mejores clientes lleguen a tu equipo de ventas, mes a mes.
            </p>
            <div className="flex flex-col items-center gap-3">
              <button
                onClick={scrollToTop}
                className="bg-[#0c6ac3] text-white hover:bg-[#0a5aa5] px-8 py-4 rounded-full text-lg font-semibold transition-all hover:scale-110 shadow-lg"
              >
                Agendá una llamada
              </button>
              <span className="text-sm text-muted-foreground font-medium px-4 py-1.5 bg-secondary rounded-full">
                Solo para empresas que venden software o servicios B2B con ticket de alto valor
              </span>
            </div>
          </div>

          {/* Right Column - Calendly Widget */}
          <div className="w-full">
            <div className="rounded-lg shadow-2xl bg-white border border-border">
              <div
                dangerouslySetInnerHTML={{
                  __html: `<!-- Calendly inline widget begin --><div class="calendly-inline-widget" data-url="https://calendly.com/angelograsselli/llamada-de-consulta?hide_event_type_details=1&hide_gdpr_banner=1" style="min-width:320px;height:700px;"></div><script type="text/javascript" src="https://assets.calendly.com/assets/external/widget.js" async></script><!-- Calendly inline widget end -->`,
                }}
              />
            </div>
          </div>
        </div>
      </div>
    </section>
  )
}
