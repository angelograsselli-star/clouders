"use client"

import { Phone, Calendar, Video } from "lucide-react"

interface CTAButtonProps {
  variant?: "phone" | "calendar" | "video"
}

export function CTAButton({ variant = "phone" }: CTAButtonProps) {
  const scrollToCalendar = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  const iconMap = {
    phone: Phone,
    calendar: Calendar,
    video: Video,
  }

  const Icon = iconMap[variant]

  return (
    <div className="flex justify-center py-12">
      <button
        onClick={scrollToCalendar}
        className="bg-[#0c6ac3] text-white hover:bg-[#0a5aa5] px-8 py-4 rounded-full text-lg font-semibold transition-all hover:scale-110 shadow-lg flex items-center gap-2"
      >
        <Icon className="w-5 h-5" />
        Agendá una llamada
      </button>
    </div>
  )
}
