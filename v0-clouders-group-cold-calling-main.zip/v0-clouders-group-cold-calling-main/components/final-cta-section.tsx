"use client"

export function FinalCTASection() {
  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
  }

  return (
    <section className="py-12 md:py-20 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8 md:gap-12 items-center max-w-7xl mx-auto">
          {/* Left Column - Text */}
          <div className="space-y-4 md:space-y-6">
            <h2 className="text-2xl sm:text-3xl md:text-4xl lg:text-5xl font-bold text-black leading-tight">
              Nuestro sistema es <span className="text-[#0c6ac3]">simple</span>. Y funciona.
            </h2>
            <p className="text-lg sm:text-xl text-gray-600 leading-relaxed">
              En medio de tanto "AI-powered esto" y "automatización asombrosa lo otro", nosotros preferimos ir a lo
              simple: un sistema probado que ya ayudó a otras startups B2B a escalar su adquisición de forma predecible.
            </p>
            <p className="text-lg sm:text-xl text-gray-600 leading-relaxed">
              Marketing y ventas son los pulmones de tu negocio. Sin aire constante, no hay crecimiento. Nuestro trabajo
              es garantizar que ese aire nunca falte.
            </p>
            <div>
              <button
                onClick={scrollToTop}
                className="bg-[#0c6ac3] text-white hover:bg-[#0a5aa5] px-8 py-4 rounded-full text-lg font-semibold transition-all hover:scale-110 shadow-lg"
              >
                Agendá una llamada
              </button>
            </div>
          </div>

          {/* Right Column - Calendar */}
          <div className="bg-white rounded-2xl shadow-2xl p-2 md:p-4">
            <div
              dangerouslySetInnerHTML={{
                __html: `<!-- Calendly inline widget begin --><div class="calendly-inline-widget" data-url="https://calendly.com/angelograsselli/llamada-de-consulta?hide_event_type_details=1&hide_gdpr_banner=1" style="min-width:320px;height:700px;"></div><script type="text/javascript" src="https://assets.calendly.com/assets/external/widget.js" async></script><!-- Calendly inline widget end -->`,
              }}
            />
          </div>
        </div>
      </div>
    </section>
  )
}
