"use client"

import Image from "next/image"
import { Menu, X } from "lucide-react"
import { useState } from "react"

export function Header() {
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false)

  const scrollToSection = (sectionId: string) => {
    const element = document.getElementById(sectionId)
    if (element) {
      element.scrollIntoView({ behavior: "smooth" })
    }
    setIsMobileMenuOpen(false)
  }

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: "smooth" })
    setIsMobileMenuOpen(false)
  }

  return (
    <header className="sticky top-0 z-50 w-full border-b border-border bg-white">
      <div className="container mx-auto flex h-16 items-center justify-between px-4 md:px-6">
        <div className="flex items-center gap-2">
          <Image
            src="/images/image-202-20-281-29.png"
            alt="Clouders Group Logo"
            width={32}
            height={32}
            className="h-8 w-8"
          />
          <span className="text-lg md:text-xl font-bold text-foreground">Clouders Group</span>
        </div>

        <nav className="hidden lg:flex items-center gap-6 absolute left-1/2 transform -translate-x-1/2">
          <button
            onClick={() => scrollToSection("sistema")}
            className="text-base md:text-lg font-semibold text-foreground hover:text-[#0c6ac3] transition-colors px-2 py-1"
          >
            Nuestro sistema
          </button>
          <button
            onClick={() => scrollToSection("contenido")}
            className="text-base md:text-lg font-semibold text-foreground hover:text-[#0c6ac3] transition-colors px-2 py-1"
          >
            Contenido
          </button>
        </nav>

        <div className="hidden lg:flex">
          <button
            onClick={scrollToTop}
            className="bg-[#0c6ac3] text-white hover:bg-[#0a5aa5] px-5 py-2 rounded-full text-base font-semibold transition-all hover:scale-105 shadow"
          >
            Agendá una llamada
          </button>
        </div>

        <button
          className="lg:hidden p-2 text-foreground hover:text-[#0c6ac3] transition-colors"
          onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
          aria-label="Toggle menu"
        >
          {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
        </button>
      </div>

      {isMobileMenuOpen && (
        <div className="lg:hidden border-t border-border bg-white">
          <nav className="container mx-auto px-4 py-4 flex flex-col gap-4">
            <button
              onClick={() => scrollToSection("sistema")}
              className="text-left text-base font-semibold text-foreground hover:text-[#0c6ac3] transition-colors py-2"
            >
              Nuestro sistema
            </button>
            <button
              onClick={() => scrollToSection("contenido")}
              className="text-left text-base font-semibold text-foreground hover:text-[#0c6ac3] transition-colors py-2"
            >
              Contenido
            </button>
            <button
              onClick={scrollToTop}
              className="bg-[#0c6ac3] text-white hover:bg-[#0a5aa5] px-5 py-2 rounded-full text-base font-semibold transition-all text-left"
            >
              Agendá una llamada
            </button>
          </nav>
        </div>
      )}
    </header>
  )
}
