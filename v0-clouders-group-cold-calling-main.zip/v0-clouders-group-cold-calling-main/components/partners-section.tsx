import Image from "next/image"

export function PartnersSection() {
  const partners = [
    { name: "Apollo", src: "/images/image.png" },
    { name: "Clay", src: "/images/image.png" },
    { name: "Prospeo", src: "/images/image.png" },
    { name: "Hunter.io", src: "/hunter-io-logo.png" },
    { name: "Lemlist", src: "/lemlist-logo.jpg" },
    { name: "Instantly", src: "/instantly-logo.png" },
  ]

  return (
    <section className="py-16 md:py-24 bg-black">
      <div className="container mx-auto px-4 md:px-6">
        <h2 className="text-center text-gray-400 text-sm font-medium uppercase tracking-wider mb-12">Partners de</h2>
        <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-8 items-center max-w-6xl mx-auto">
          {partners.map((partner) => (
            <div
              key={partner.name}
              className="flex items-center justify-center grayscale hover:grayscale-0 transition-all duration-300 opacity-60 hover:opacity-100"
            >
              <Image
                src={partner.src || "/placeholder.svg"}
                alt={partner.name}
                width={160}
                height={80}
                className="object-contain max-h-12"
              />
            </div>
          ))}
        </div>
      </div>
    </section>
  )
}
