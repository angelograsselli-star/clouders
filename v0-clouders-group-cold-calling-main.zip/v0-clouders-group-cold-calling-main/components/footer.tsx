export function Footer() {
  return (
    <footer className="bg-black text-white py-12">
      <div className="container mx-auto px-4">
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-8">
          {/* Logo y descripción */}
          <div className="sm:col-span-2 md:col-span-1">
            <div className="flex items-center gap-3 mb-4">
              <img src="/logo.png" alt="Clouders Group Logo" className="h-10 w-10" />
              <h3 className="text-xl font-bold">Clouders Group</h3>
            </div>
            <p className="text-gray-400 text-sm">
              Clouders Group ayuda a empresas de software y servicios B2B a escalar su adquisición de clientes con un
              sistema simple, probado y sin humo.
            </p>
          </div>

          {/* Enlaces */}
          <div>
            <h4 className="font-semibold mb-4">Enlaces Rápidos</h4>
            <ul className="space-y-2">
              <li>
                <a href="#sistema" className="text-gray-400 hover:text-[#0c6ac3] transition-colors text-sm">
                  Nuestro sistema
                </a>
              </li>
              <li>
                <a href="#contenido" className="text-gray-400 hover:text-[#0c6ac3] transition-colors text-sm">
                  Contenido
                </a>
              </li>
            </ul>
          </div>

          {/* Contacto */}
          <div>
            <h4 className="font-semibold mb-4">Contacto</h4>
            <div className="space-y-2 text-sm text-gray-400">
              <p>Email: contacto@cloudersgroup.com</p>
              <p>Teléfono: +54 11 1234-5678</p>
            </div>
          </div>
        </div>

        {/* Copyright */}
        <div className="border-t border-gray-800 mt-8 pt-8 text-center text-sm text-gray-400">
          <p>&copy; 2025 Clouders Group. Todos los derechos reservados.</p>
        </div>
      </div>
    </footer>
  )
}
