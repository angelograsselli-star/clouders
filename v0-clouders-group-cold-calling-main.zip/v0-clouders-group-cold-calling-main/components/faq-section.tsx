"use client"

import { useState } from "react"
import { ChevronDown } from "lucide-react"

export function FAQSection() {
  const [openIndex, setOpenIndex] = useState<number | null>(null)

  const faqs = [
    {
      question: "¿Cómo funciona el sistema de Clouders?",
      answer:
        "Trabajamos en tres áreas en paralelo: marketing (Meta Ads para generar leads calificados), comercial (optimización del proceso de venta) y estrategia (análisis y mejora continua). Todo el sistema está diseñado para que mes a mes lleguen más y mejores oportunidades a tu equipo comercial.",
    },
    {
      question: "¿Para qué tipo de empresas es esto?",
      answer:
        "Para empresas que venden software o servicios B2B con ticket de alto valor. Si tu cliente ideal es una empresa y el proceso de venta implica al menos una llamada o reunión, este sistema es para vos.",
    },
    {
      question: "¿Cuánto tiempo lleva ver los primeros resultados?",
      answer:
        "Las primeras campañas de Meta comienzan a generar leads calificados dentro de las primeras 2 a 4 semanas. Los resultados se optimizan y mejoran con el tiempo a medida que el sistema aprende.",
    },
    {
      question: "¿Necesito tener un equipo de ventas ya armado?",
      answer:
        "No necesitás un equipo grande, pero sí al menos una persona dedicada a cerrar ventas. Trabajamos con founders que venden ellos mismos y también con equipos comerciales más grandes.",
    },
    {
      question: "¿Qué diferencia tiene esto de contratar una agencia de marketing?",
      answer:
        "Las agencias tradicionales gestionan campañas. Nosotros construimos un sistema completo de adquisición: desde que el lead ve el anuncio hasta que firma. Incluye marketing, comercial y estrategia como un todo integrado.",
    },
    {
      question: "¿Cuánto cuesta trabajar con Clouders?",
      answer:
        "Depende del tamaño de tu equipo y del alcance del trabajo. Agendá una llamada y te armamos una propuesta a medida.",
    },
  ]

  return (
    <section id="preguntas" className="py-8 md:py-12 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        <div className="max-w-3xl mx-auto">
          <h2 className="text-3xl md:text-4xl font-bold text-black text-center mb-4">Preguntas frecuentes</h2>
          <p className="text-gray-600 text-center mb-12">
            Todo lo que necesitás saber sobre nuestro sistema de adquisición
          </p>

          <div className="space-y-4">
            {faqs.map((faq, index) => (
              <div key={index} className="bg-white rounded-lg border border-gray-200 overflow-hidden shadow-sm">
                <button
                  onClick={() => setOpenIndex(openIndex === index ? null : index)}
                  className="w-full px-6 py-4 flex items-center justify-between text-left hover:bg-gray-50 transition-colors"
                >
                  <span className="text-black font-medium pr-8">{faq.question}</span>
                  <ChevronDown
                    className={`flex-shrink-0 w-5 h-5 text-[#0c6ac3] transition-transform ${
                      openIndex === index ? "rotate-180" : ""
                    }`}
                  />
                </button>
                {openIndex === index && (
                  <div className="px-6 pb-4">
                    <p className="text-gray-700 leading-relaxed">{faq.answer}</p>
                  </div>
                )}
              </div>
            ))}
          </div>
        </div>
      </div>
    </section>
  )
}
