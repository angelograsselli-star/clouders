import { TrendingUp, Users, BarChart2 } from "lucide-react"

const features = [
  {
    icon: TrendingUp,
    title: "Marketing",
    description:
      "Generamos más llamadas de venta calificadas que se sientan frente a tus comerciales. Usamos Meta como canal de adquisición con creatividades y audiencias testeadas para atraer exactamente a los prospectos correctos.",
    bullets: [
      "Campañas de Meta Ads optimizadas para leads B2B",
      "Creatividades y mensajes testeados para tu ICP",
      "Flujo de nurturing hasta la llamada calificada",
    ],
  },
  {
    icon: Users,
    title: "Comercial",
    description:
      "Mejoramos todo el proceso pre-llamada y durante la llamada para que tu equipo pueda cerrar la mayor cantidad de leads calificados posibles.",
    bullets: [
      "Secuencias de seguimiento y scripts probados",
      "Setup y optimización del CRM",
      "Análisis de conversiones para mejorar el cierre",
    ],
  },
  {
    icon: BarChart2,
    title: "Estrategia",
    description:
      "Te damos las herramientas y el análisis para construir un sistema de adquisición que crece con tu compañía a lo largo del tiempo, sin depender de la suerte ni de meses buenos.",
    bullets: [
      "Análisis de data con IA para tomar mejores decisiones",
      "Definición y refinamiento de ICP y propuesta de valor",
      "Sistema de adquisición escalable y predecible",
    ],
  },
]

export function FeaturesSection() {
  const scrollToTop = () => {
    if (typeof window !== "undefined") {
      window.scrollTo({ top: 0, behavior: "smooth" })
    }
  }

  return (
    <section id="sistema" className="py-8 md:py-12 bg-white">
      <div className="container mx-auto px-4 md:px-6">
        {/* Section Header */}
        <div className="text-center mb-12 md:mb-16">
          <h2 className="text-3xl md:text-4xl lg:text-5xl font-bold text-foreground mb-4 text-balance">
            Más y mejores oportunidades de venta frente a tus comerciales
          </h2>
          <p className="text-lg md:text-xl text-muted-foreground max-w-3xl mx-auto text-pretty">
            Solo para empresas que venden software o servicios B2B con ticket de alto valor.
          </p>
        </div>

        {/* Features Grid */}
        <div className="grid gap-6 lg:grid-cols-3 max-w-6xl mx-auto">
          {features.map((feature, index) => {
            const Icon = feature.icon
            return (
              <div
                key={index}
                className="relative group p-8 md:p-10 rounded-xl border border-border bg-card shadow-lg hover:shadow-xl transition-all duration-300 hover:scale-[1.02]"
              >
                <div className="mb-4">
                  <div className="inline-flex p-3 rounded-lg bg-primary/10">
                    <Icon className="h-6 w-6 text-primary" />
                  </div>
                </div>
                <h3 className="text-2xl font-semibold text-card-foreground mb-3">{feature.title}</h3>
                <p className="text-muted-foreground text-pretty mb-5">{feature.description}</p>
                <ul className="space-y-2">
                  {feature.bullets.map((bullet, i) => (
                    <li key={i} className="flex items-start gap-2 text-sm text-muted-foreground">
                      <span className="mt-1 h-1.5 w-1.5 flex-shrink-0 rounded-full bg-primary" />
                      {bullet}
                    </li>
                  ))}
                </ul>
              </div>
            )
          })}
        </div>

        {/* CTA */}
        <div className="flex justify-center mt-12">
          <button
            onClick={scrollToTop}
            className="bg-[#0c6ac3] text-white hover:bg-[#0a5aa5] px-8 py-4 rounded-full text-lg font-semibold transition-all hover:scale-110 shadow-lg"
          >
            Agendá una llamada
          </button>
        </div>
      </div>
    </section>
  )
}
